// QuakeBeacon Service Worker
// Caches the entire app for offline use — critical in disaster scenarios
// CC0 1.0 Universal — Public Domain

const CACHE_NAME = 'quakebeacon-v1';
const FONTS_CACHE = 'quakebeacon-fonts-v1';

// Core app files to cache immediately on install
const CORE_FILES = [
  '/',
  '/index.html',
  '/manifest.json',
];

// Google Fonts to cache for offline use
const FONT_URLS = [
  'https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Share+Tech+Mono&family=Barlow+Condensed:wght@400;600&display=swap',
];

// ── INSTALL: cache everything immediately ──────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    Promise.all([
      caches.open(CACHE_NAME).then(cache => cache.addAll(CORE_FILES)),
      caches.open(FONTS_CACHE).then(cache => cache.addAll(FONT_URLS).catch(() => {})),
    ]).then(() => self.skipWaiting())
  );
});

// ── ACTIVATE: clean up old caches ─────────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys
          .filter(k => k !== CACHE_NAME && k !== FONTS_CACHE)
          .map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// ── FETCH: serve from cache, fall back to network ─────────
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  // Fonts — cache-first (they never change)
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith(
      caches.open(FONTS_CACHE).then(cache =>
        cache.match(request).then(cached => {
          if (cached) return cached;
          return fetch(request).then(response => {
            cache.put(request, response.clone());
            return response;
          }).catch(() => cached || new Response('', { status: 503 }));
        })
      )
    );
    return;
  }

  // App shell — cache-first, background update
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.open(CACHE_NAME).then(cache =>
        cache.match(request).then(cached => {
          const networkFetch = fetch(request).then(response => {
            if (response.ok) cache.put(request, response.clone());
            return response;
          }).catch(() => null);

          // Return cached immediately; update cache in background
          return cached || networkFetch || new Response(
            '<h1>QuakeBeacon — Offline</h1><p>Open the app while online first to cache it.</p>',
            { headers: { 'Content-Type': 'text/html' }, status: 503 }
          );
        })
      )
    );
    return;
  }

  // Everything else — network with cache fallback
  event.respondWith(
    fetch(request).catch(() => caches.match(request))
  );
});

// ── BACKGROUND SYNC: retry location SMS when back online ──
self.addEventListener('sync', event => {
  if (event.tag === 'beacon-location-sync') {
    event.waitUntil(syncBeaconLocation());
  }
});

async function syncBeaconLocation() {
  // Placeholder — extend to POST GPS coords to emergency endpoint
  console.log('[QuakeBeacon SW] Background sync: beacon location');
}

// ── PUSH NOTIFICATIONS: earthquake alerts ─────────────────
self.addEventListener('push', event => {
  const data = event.data?.json() || {};
  event.waitUntil(
    self.registration.showNotification(data.title || '⚠ EARTHQUAKE ALERT', {
      body: data.body || 'Strong seismic activity detected. Tap to activate beacon.',
      icon: '/manifest.json',
      badge: '/manifest.json',
      tag: 'quake-alert',
      requireInteraction: true,
      vibrate: [200,100,200,100,200,300,500,100,500,100,500],
      actions: [
        { action: 'activate', title: '⚡ ACTIVATE BEACON' },
        { action: 'dismiss',  title: 'Dismiss' },
      ],
      data: { url: '/index.html#beacon' },
    })
  );
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action === 'activate' || !event.action) {
    event.waitUntil(
      clients.matchAll({ type: 'window' }).then(clientList => {
        for (const client of clientList) {
          if (client.url.includes('/index.html') && 'focus' in client) {
            client.postMessage({ action: 'ACTIVATE_BEACON' });
            return client.focus();
          }
        }
        return clients.openWindow('/index.html#beacon');
      })
    );
  }
});
